import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class UserManagementTest {
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.get("http://notary.runasp.net/login");

        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));

    }

    @Test(priority = 1)
    void usermanagement (){
        WebElement usermanagementBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-mainlayout/app-mainmenu/div/div[2]/div[2]/div[5]")
        ));
        usermanagementBtn.click();
        js.executeScript("window.scrollBy(0,250)");
    }

    @Test(priority = 2)
    void usermanage (){
        WebElement usermanageBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/div/app-user-managment-dashboard/div/div[2]/div[1]/div[2]/p")
        ));
        usermanageBtn.click();
        js.executeScript("window.scrollBy(0,250)");
    }

    @Test(priority = 3)
    void dashboard (){
        WebElement dashboardBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/nav/ul/li[1]/div/span")
        ));
        dashboardBtn.click();
        js.executeScript("window.scrollBy(0,250)");
    }

    @Test(priority = 4)
    void roleManagement (){
        WebElement rolemanagementBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/div/app-user-managment-dashboard/div/div[2]/div[2]/div[2]/p")
        ));
        rolemanagementBtn.click();
        js.executeScript("window.scrollBy(0,250)");
    }


    @Test(priority = 5)
    void toggle (){
        WebElement toggleBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/div[1]/button/lucide-angular/svg")
        ));
        toggleBtn.click();
        js.executeScript("Window.scrollBy(0,250)");
    }
/*
    @Test(priority = 6)
    void toggle1 (){
        WebElement toggleBtn1 = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/div[1]/button/lucide-angular")
        ));
        toggleBtn1.click();
        js.executeScript("Window.scrollBy(0,250)");
    }

     */

    @Test(priority = 7)
    void logout (){
        WebElement logoutBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/div[2]/div/app-button")
        ));
        logoutBtn.click();
        js.executeScript("Window.scrollBy(0,250)");
    }

    @AfterTest
    void teardown() throws InterruptedException {

        // Wait for 10 seconds before closing browser
        Thread.sleep(10000);

        if (driver != null) {
            driver.quit();
        }
    }
}
