import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class NotaryTest {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    private void scrollTo(WebElement el) {
        js.executeScript("arguments[0].scrollIntoView({block:'center'});", el);
    }

    private void selectDropdown(WebElement el, int index) {
        scrollTo(el);
        wait.until((WebDriver d) -> new Select(el).getOptions().size() > index);
        new Select(el).selectByIndex(index);
    }

    private void fillInput(WebElement el, String value) {
        scrollTo(el);
        el.clear();
        el.sendKeys(value);
    }

    // Opens the created-memo dialog, selects a row (1-based), clicks Proceed,
    // waits for dialog to close
    private void openMemoDialog(int rowIndex) {
        driver.get("http://notary.runasp.net/created-memo");

        WebElement createBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav-content/app-created-memo/div[2]/div[1]/button")));
        createBtn.click();

        // Wait for dialog table rows to be visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/div/div"
                        + "/app-not-request-select-dialog/mat-dialog-content/div[2]/table")));

        WebElement row = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/div/div"
                        + "/app-not-request-select-dialog/mat-dialog-content"
                        + "/div[2]/table/tbody/tr[" + rowIndex + "]/td[2]")));
        row.click();

        // Click Proceed button directly (not a child span/div)
        WebElement proceed = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/div/div"
                        + "/app-not-request-select-dialog/mat-dialog-actions/button[2]")));
        proceed.click();

        // Wait for dialog to fully close before touching the form
        wait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container")));
    }

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js   = (JavascriptExecutor) driver;

        driver.get("http://notary.runasp.net/login");

        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));
    }

    @Test(priority = 1)
    void notaryIntroPageLoads() {
        driver.get("http://notary.runasp.net/notary-intro");
        wait.until(ExpectedConditions.urlContains("notary-intro"));
        Assert.assertTrue(driver.getCurrentUrl().contains("notary-intro"),
                "Notary intro page did not load");
    }

    @Test(priority = 2)
    void notaryIntroPageHasContent() {
        driver.get("http://notary.runasp.net/notary-intro");
        WebElement body = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.tagName("app-root")));
        Assert.assertTrue(body.isDisplayed(), "Page content is not visible");
    }

    @Test(priority = 3)
    void notaryIntroHasNavigationButton() {
        driver.get("http://notary.runasp.net/notary-intro");
        WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("button, a[routerlink]")));
        Assert.assertTrue(btn.isDisplayed(), "No navigation button found on notary intro page");
    }

    @Test(priority = 4)
    void navigateToNotarySubMenu() {
        driver.get("http://notary.runasp.net/notary-intro");

        WebElement notaryMenu = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list"
                        + "/app-menu-item[2]/div/a/span/span/span")));
        notaryMenu.click();

        WebElement notarySubMenu = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list"
                        + "/app-menu-item[2]/div/div/app-menu-item[1]/a/span/span/span")));
        notarySubMenu.click();

        wait.until(ExpectedConditions.not(
                ExpectedConditions.urlToBe("http://notary.runasp.net/notary-intro")));
        Assert.assertFalse(driver.getCurrentUrl().equals("http://notary.runasp.net/notary-intro"),
                "Navigation did not occur after clicking submenu");
    }

    @Test(priority = 5)
    void fillNotaryForm() {
        driver.get("http://notary.runasp.net/notary-intro");

        WebElement notaryMenu = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list"
                        + "/app-menu-item[2]/div/a/span/span/span")));
        notaryMenu.click();

        WebElement notarySubMenu = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list"
                        + "/app-menu-item[2]/div/div/app-menu-item[1]/a/span/span/span")));
        notarySubMenu.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("form")));

        final String F = "/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                + "/mat-sidenav-content/app-not-request-form/div[2]/div/form";

        WebElement serviceType = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[1]/div[2]/div[1]/div/select")));
        selectDropdown(serviceType, 2);

        WebElement applicantName = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[1]/div[2]/div[2]//input[not(@type='hidden') and not(@readonly)]")));
        fillInput(applicantName, "Rashan Rahul");

        WebElement nicNumber = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[1]/div[2]/div[3]/div/div/div[1]/input")));
        fillInput(nicNumber, "123456789724");

        WebElement phone = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[1]/div[2]/div[4]/div/input")));
        fillInput(phone, "074567");

        WebElement uploadArea = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[2]/div[2]/div[1]/div")));
        scrollTo(uploadArea);
        uploadArea.click();
        WebElement fileInput = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//input[@type='file']")));
        fileInput.sendKeys("C:\\Users\\DELL\\Downloads\\Application-Format-PL-Grades-For-all-PL-Grades-2026-English.pdf");

        WebElement description = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[1]/div/div/textarea")));
        fillInput(description, "New York test");

        WebElement reportToggle = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[1]/div[1]/label/div")));
        scrollTo(reportToggle);
        reportToggle.click();
        WebElement reportAmount = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[1]/div[2]/input")));
        fillInput(reportAmount, "10001");

        WebElement vatToggle = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[2]/div[1]/label/div")));
        scrollTo(vatToggle);
        vatToggle.click();
        WebElement vatAmount = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[2]/div[2]/input")));
        fillInput(vatAmount, "5000");

        WebElement sslToggle = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[3]/div[1]/label/div")));
        scrollTo(sslToggle);
        sslToggle.click();
        WebElement sslAmount = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[3]/div[2]/div/div[2]/div[3]/div[2]/input")));
        fillInput(sslAmount, "3000");

        WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(F + "/div[4]/div[2]/button[2]")));
        scrollTo(submitBtn);
        submitBtn.click();

        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("not-request-form")));
        Assert.assertFalse(driver.getCurrentUrl().contains("not-request-form"),
                "Form was not submitted — still on form page");
    }

    // ─── Priority 6: Title Report Instruction Memo ────────────────────────────
    @Test(priority = 6)
    void titleReportInstructionMemo() {
        openMemoDialog(1); // row 1 = Title Report

        final String T1 = "/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                + "/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div"
                + "/mat-tab-body[1]/div/app-header-form/form";

        WebElement fileRef = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T1 + "/div[2]/div[3]/div/input")));
        fillInput(fileRef, "ABC-123");
        Assert.assertTrue(fileRef.isDisplayed(), "File reference input is not displayed");

        WebElement clientName = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T1 + "/div[3]/div[1]/div/input")));
        fillInput(clientName, "CHR");
        Assert.assertTrue(clientName.isDisplayed(), "Client name input is not displayed");

        WebElement branchDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T1 + "/div[3]/div[2]/div/select")));
        selectDropdown(branchDropdown, 1);
        Assert.assertTrue(branchDropdown.isDisplayed(), "Branch dropdown is not displayed");

        WebElement userDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T1 + "/div[3]/div[3]/div/select")));
        selectDropdown(userDropdown, 1);
        Assert.assertTrue(userDropdown.isDisplayed(), "User dropdown is not displayed");

        WebElement nextBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div"
                        + "/mat-tab-body[1]/div/div/button[2]")));
        scrollTo(nextBtn);
        nextBtn.click();

        wait.until(ExpectedConditions.urlContains("dashboard"));
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"),
                "Failed after submitting Title Report Instruction Memo");
    }

    // ─── Priority 7: Title Search Instruction Memo ────────────────────────────
    @Test(priority = 7)
    void titleSearchInstructionMemo() {
        openMemoDialog(2); // row 2 = Title Search

        // ── FIX: Tab 2 is NOT active by default after dialog closes.
        // Explicitly click the second tab label to activate mat-tab-body[2].
        WebElement tab2Label = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group"
                        + "/mat-tab-header/div[2]/div/div/mat-tab-label-container/div"
                        + "/mat-tab-label[2]")));
        tab2Label.click();

        // Wait for Tab 2 form to become visible after clicking the tab
        final String T2 = "/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                + "/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div"
                + "/mat-tab-body[2]/div/app-header-form2/form";

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(T2)));

        // Applicant name
        WebElement applicantName = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[2]/div[1]/div/input")));
        fillInput(applicantName, "Rashan Rahul");
        Assert.assertTrue(applicantName.isDisplayed(), "Applicant name field is not displayed");

        // Address
        WebElement address = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[2]/div[2]/div/input")));
        fillInput(address, "Araliya, Udalamatta, Galle.");
        Assert.assertTrue(address.isDisplayed(), "Address field is not displayed");

        // NIC number
        WebElement nicNumber = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[3]/div[1]/div/input")));
        fillInput(nicNumber, "123456789V");
        Assert.assertTrue(nicNumber.isDisplayed(), "NIC field is not displayed");

        // NIC type dropdown
        WebElement nicTypeDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/div[3]/div[2]/div/select")));
        selectDropdown(nicTypeDropdown, 1);
        Assert.assertTrue(nicTypeDropdown.isDisplayed(), "NIC type dropdown is not displayed");

        // Phone
        WebElement phone = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[3]/div[2]/div/input")));
        fillInput(phone, "0778098533");
        Assert.assertTrue(phone.isDisplayed(), "Phone field is not displayed");

        // Email
        WebElement email = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[4]/div[2]/div/input")));
        fillInput(email, "test@gmail.com");
        Assert.assertTrue(email.isDisplayed(), "Email field is not displayed");

        // District dropdown
        WebElement districtDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[3]/div[4]/div/select")));
        selectDropdown(districtDropdown, 2);
        Assert.assertTrue(districtDropdown.isDisplayed(), "District dropdown is not displayed");

        // Division dropdown
        WebElement divisionDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div/mat-tab-body[2]/div/app-header-form2/form/div[6]/div[2]/div[1]/select")));
        selectDropdown(divisionDropdown, 2);
        Assert.assertTrue(divisionDropdown.isDisplayed(), "Division dropdown is not displayed");

        // Lot type dropdown
        WebElement lotTypeDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/div[6]/div[2]/div[3]/select")));
        selectDropdown(lotTypeDropdown, 2);
        Assert.assertTrue(lotTypeDropdown.isDisplayed(), "Lot type dropdown is not displayed");

        // Extent value
        WebElement extent = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(T2 + "/div[6]/div[2]/div[4]/input")));
        fillInput(extent, "1234");
        Assert.assertTrue(extent.isDisplayed(), "Extent field is not displayed");

        // Next button
        WebElement nextBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container"
                        + "/mat-sidenav-content/app-dashboard/app-tabs/div/mat-tab-group/div"
                        + "/mat-tab-body[2]/div/div/button[2]")));
        scrollTo(nextBtn);
        nextBtn.click();

        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("created-memo")));
        Assert.assertFalse(driver.getCurrentUrl().contains("created-memo"),
                "Title Search form did not navigate after submit");
    }




    @AfterTest
    void teardown() throws InterruptedException {
        Thread.sleep(10000);
        if (driver != null) {
            driver.quit();
        }
    }
}
