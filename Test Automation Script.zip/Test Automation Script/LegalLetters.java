import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class LegalLetters {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.get("http://notary.runasp.net/login");

        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));

    }

    // ─── Priority 1: Navigate to Legal Letters page ───────────────────────────
    @Test(priority = 1)
    void legalletter (){
        WebElement legalLetterBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-mainlayout/app-mainmenu/div/div[2]/div[2]/div[3]/div[2]/span")
        ));
        legalLetterBtn.click();
        js.executeScript("windows.scrollBy(0, 250)");
    }

    @Test(priority = 2)
    void open (){
        WebElement openBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/div[1]/main/main/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[8]/button")
        ));
        openBtn.click();
        js.executeScript("windows.scrollBy(0,250)");
    }

    // ─── Teardown ─────────────────────────────────────────────────────────────
    @AfterTest
    void teardown() throws InterruptedException {
        Thread.sleep(10000);
        if (driver != null) {
            driver.quit();
        }
    }
}
