import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class LoginTest {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("http://notary.runasp.net/login");
    }

    @Test
    void validLogin() {
        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));
        Assert.assertTrue(driver.getCurrentUrl().contains("mainmenu"), "Login failed: not redirected to mainmenu");
    }

    @AfterTest
    void teardown() throws InterruptedException {

        // Wait for 10 seconds before closing browser
        Thread.sleep(10000);

        if (driver != null) {
            driver.quit();
        }
    }
}
