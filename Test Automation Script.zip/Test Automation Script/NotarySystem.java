import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class NotarySystem {
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeTest
                void setup() {
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    driver.manage().window().maximize();
                    wait = new WebDriverWait(driver, Duration.ofSeconds(20));
                    js = (JavascriptExecutor) driver;
                    driver.get("http://notary.runasp.net/login");

                    WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
                    WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector("input[type='password']")));
                    WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                            By.cssSelector("button[type='submit']")));

                    username.sendKeys("Admin");
                    password.sendKeys("Thimi@1234");
                    loginBtn.click();

                    wait.until(ExpectedConditions.urlContains("mainmenu"));

                }

    @Test(priority = 1)
    void Notary (){
        WebElement notaryBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-mainlayout/app-mainmenu/div/div[2]/div[2]/div[2]/div[1]/img")
        ));
        notaryBtn.click();
        js.executeScript("window.scrollBy(0,500)");

    }

    @Test(priority = 2)
    void titleReport (){
        WebElement TitleReportBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/a/span/span/span")

        ));
        TitleReportBtn.click();

        js.executeScript("window.scrollBy(0, 500)");
    }

    @Test(priority = 3)
    void payment (){

        WebElement paymentBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[1]/a/span")
        ));
        paymentBtn.click();

        js.executeScript("window.scrollBy(0, 500)");

    }

    @Test(priority = 4)
    void createMemo (){

        WebElement createMemoBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[2]/a/span/span/span")
        ));
        createMemoBtn.click();

        js.executeScript("window.scrollBy(0, 500)");

    }

    @Test (priority = 5)
    void approveMemo (){
        WebElement approveMemoBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[3]/a/span")
        ));
        approveMemoBtn.click();
        js.executeScript("window.scrollBy(0, 500)");
    }

    @Test (priority = 6)
        void examination (){
            WebElement examinationBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[4]/a")
            ));
            examinationBtn.click();
            js.executeScript("window.scrollBy(0, 500)");
        }


     @Test (priority = 7)
     void AttachDoc (){
         WebElement attachDocBtn = wait.until(ExpectedConditions.elementToBeClickable(
                 By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[5]/a/span")
         ));
         attachDocBtn.click();
         js.executeScript("window.scrollBy(0, 500)");
     }

     @Test (priority = 8)
     void BranchAppro () {
        WebElement branchApproBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[6]/a/span/span/span")
        ));
        branchApproBtn.click();
        js.executeScript("window.scrollBy(0, 500)");
     }

     @Test (priority = 9)
     void FinishedReport () {
        WebElement finishedReportBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[7]/a/span")
        ));
        finishedReportBtn.click();
        js.executeScript("window.scrollBy(0, 500)");
     }

     @Test (priority = 10)
     void Setting (){
        WebElement settingBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[2]/div/div/app-menu-item[8]/a/span/span/span")
        ));
        settingBtn.click();
        js.executeScript("window.scrollBy(0, 500)");
     }



    @AfterTest
    void teardown() throws InterruptedException {

        // Wait for 10 seconds before closing browser
        Thread.sleep(10000);

        if (driver != null) {
            driver.quit();
        }
    }
}
