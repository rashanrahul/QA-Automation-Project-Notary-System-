import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class UserManagement {
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.get("http://notary.runasp.net/login");

        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));

    }

    @Test (priority = 1)
    void usermanagement (){
        WebElement usermanagementBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-mainlayout/app-mainmenu/div/div[2]/div[2]/div[5]/div[2]/span")
        ));
        usermanagementBtn.click();
        js.executeScript("window.scrollBy(0,250)");
    }

    @Test (priority = 2)
    void adduser () {
        WebElement adduserBtn = wait. until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/nav/ul/li[2]/div")
        ));
        adduserBtn.click();
        js.executeScript("window.scrollBy(0, 250)");
    }

    @Test (priority = 3)
    void addrole (){
        WebElement addroleBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-navbarlayout/div/app-sidebar/div/nav/ul/li[3]/div/span")
        ));
        addroleBtn.click();
        js.executeScript("window.scrollBy(0, 250)");
    }


    @AfterTest
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

}
