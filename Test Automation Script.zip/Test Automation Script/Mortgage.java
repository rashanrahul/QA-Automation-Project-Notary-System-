import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class Mortgage {
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeTest
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.get("http://notary.runasp.net/login");

        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='text'], input[formcontrolname='username'], input[name='username'], input[placeholder*='ser']")));
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("input[type='password']")));
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[type='submit']")));

        username.sendKeys("Admin");
        password.sendKeys("Thimi@1234");
        loginBtn.click();

        wait.until(ExpectedConditions.urlContains("mainmenu"));

    }

    @Test (priority = 0)
    void Notary () {
        WebElement NotaryBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-mainlayout/app-mainmenu/div/div[2]/div[2]/div[2]/div[1]")
        ));
        NotaryBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 1)
    void Mortgage (){
        WebElement MortgageBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/a/span/span/span")
        ));
        MortgageBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test(priority = 2)
    void MBDintro () {
        WebElement MBDBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[1]/a/span")
        ));
        MBDBtn.click();
        js.executeScript("window.scrollBy(0,250)", "");
    }

    @Test(priority = 3)
    void ApproveMBD () {
        WebElement approvebtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[2]/a/span/span/span")
        ));
        approvebtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 4)
    void AttachRequir () {
        WebElement attachreqBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[3]/a/span")
        ));
        attachreqBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 5)
    void MBDpreparation () {
        WebElement MBDprepBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[4]/a/span/span/span")
        ));
        MBDprepBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 6)
    void signDate () {
        WebElement signDateBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[5]/a/span")
        ));
        signDateBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 7)
    void finalBranch (){
        WebElement finalBranchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[6]/a/span")
        ));
        finalBranchBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 8)
    void attachRecomment () {
        WebElement attachRecommentBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[7]/a/span/span/span")
        ));
        attachRecommentBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");
    }

    @Test (priority = 9)
    void FinalMortgage () {
        WebElement finalMortgageBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[8]/a/span/span/span")
        ));
        finalMortgageBtn.click();
        js.executeScript("window.scrollBy(0,250)", "");
    }

    @Test (priority = 10)
    void checkList (){
        WebElement checklistBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/app-root/app-dashboard-layout/mat-sidenav-container/mat-sidenav/div/app-custom-sidenav/div/div[2]/mat-nav-list/app-menu-item[3]/div/div/app-menu-item[9]/a/span/span/span")
        ));
        checklistBtn.click();
        js.executeScript("window.scrollBy(0, 250)", "");

    }



    @AfterTest
    void teardown() throws InterruptedException {

        // Wait for 10 seconds before closing browser
        Thread.sleep(10000);

        if (driver != null) {
            driver.quit();
        }
    }
}
